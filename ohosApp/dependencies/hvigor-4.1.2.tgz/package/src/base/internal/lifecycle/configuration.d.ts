import { HvigorCoreNode } from '../../external/core/hvigor-core-node.js';
/**
 * Config整个hvigor的项目，进行数据绑定
 *
 */
export declare function configuration(): Promise<HvigorCoreNode>;
