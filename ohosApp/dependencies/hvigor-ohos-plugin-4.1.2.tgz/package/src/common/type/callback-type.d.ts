/**
 * 定义一个返回boolean的回调函数类型
 */
export declare type BooleanCallback = (...args: any[]) => boolean;
