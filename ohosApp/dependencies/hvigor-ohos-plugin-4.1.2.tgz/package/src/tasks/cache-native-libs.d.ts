import { FileSet } from '@ohos/hvigor';
import { AbstractNativeStrip } from './abstract/abstract-native-strip.js';
import { TargetTaskService } from './service/target-task-service.js';
/**
 * build-native-strip任务执行完执行这个任务把本次的strip结果落盘保存
 */
export declare class CacheNativeLibs extends AbstractNativeStrip {
    private _log;
    constructor(targetService: TargetTaskService);
    declareOutputFiles(): FileSet;
    protected doTaskAction(): Promise<void>;
    taskShouldDo(): boolean;
    declareInputFiles(): FileSet;
    initTaskDepends(): void;
}
