/**
 * 工程中的常用变量
 *
 * @since 2021/12/29
 */
export declare class CommonConst {
    static readonly HARMONY_OS: string;
    static readonly BUILD_FILE_NAME: string;
    static readonly PACKAGE_JSON: string;
    static readonly OH_PACKAGE_JSON5: string;
    static readonly OH_MODULES: string;
    static readonly CACHE: string;
    static readonly BUILD: string;
    static readonly REMOTE_HSP: string;
    static readonly BUILD_PROFILE_FIELDS: string;
    static readonly BUILD_MODE: string;
    static readonly BUILD_MODE_NAME: string;
    static readonly LOCAL_PROPERTIES: string;
    static readonly PROFILE_JSON5: string;
    static readonly MODULE_JSON: string;
    static readonly APP_SCHEMA_JSON: string;
    static readonly FORM_SCHEMA_JSON: string;
    static readonly PAGE_SCHEMA_JSON: string;
    static readonly MODULE_JSON5: string;
    static readonly CONFIG_JSON: string;
    static readonly APP_CONFIG: string;
    static readonly ETS_WEBPACK_FILE: string;
    static readonly ACE_RICH_WEBPACK_FILE: string;
    static readonly ACE_LITE_WEBPACK_FILE: string;
    static readonly DEBUGGABLE: string;
    static readonly HOT_RELOAD: string;
    static readonly DEBUG_LINE: string;
    static readonly PREVIEW_MODE: string;
    static readonly UNIT_TEST_MODE: string;
    static readonly OHOS_TEST_COVERAGE_SCOPE: string;
    static readonly OHOS_TEST_COVERAGE_ALIAS: string;
    static readonly OHOS_TEST_COVERAGE: string;
    static readonly RPCID_JSON: string;
    static readonly RPCID_SC: string;
    static readonly PCID_SC: string;
    static readonly SYSCAP_JSON: string;
    static readonly DEVICES_GENERAL: string;
    static readonly DEVICES_CUSTOM: string;
    static readonly RES_CONFIG_FILE: string;
    static readonly WARM_UP_SCRIPT: string;
    static readonly ADDED_SYSCAPS: string;
    static readonly REMOVED_SYSCAPS: string;
    static readonly SYSTEM_CAPABILITY: string;
    static readonly DEVICE_TYPE: string;
    static readonly DEVICE_TYPES: string;
    static readonly COMPILE_CONFIG: string;
    static readonly PATCH_CONFIG: string;
    static readonly FRAMEWORK_CONFIGURATION: string;
    static readonly SINGLE_FRAMEWORK: string;
    static readonly DOUBLE_FRAMEWORK: string;
    static readonly OPEN_HARMONY: string;
    static readonly BASE_PROFILE: string;
    static readonly ASSEMBLE_APP: string;
    static readonly ASSEMBLE_HAP: string;
    static readonly DEFAULT_PACKAGE_NAME: string;
    static readonly DEFAULT_MODULE_NAME: string;
    static readonly DEFAULT_DESIGN_WIDTH: number;
    static readonly OBFUSCATION_TXT: string;
    static readonly DISTRO_FILTER: string;
    static readonly OHOS_SDK_COMPONENT_DEFINITION: string;
    static readonly HMS_SDK_COMPONENT_DEFINITION: string;
    static readonly OBFUSCATION_FILES_HASH: string;
    static readonly OBFUSCATION_ENABLE: string;
    static readonly COMPILE_SDK_VERSION: string;
    static readonly COMPATIBLE_SDK_VERSION: string;
    static readonly TARGET_SDK_VERSION: string;
    static readonly INSIGHT_INTENT_SCHEMA_JSON: string;
    static readonly UTD_SCHEMA_JSON: string;
    static readonly ARK_DATA_SCHEMA_JSON: string;
    static readonly ENABLE_SIGN_TASK: string;
    static readonly SKIP_NATIVE_INCREMENTAL: string;
    static readonly UNIT_TEST: string;
    static readonly OHOS_TEST: string;
    static readonly COVERAGE_PATH_FILTER: string;
    static readonly COVERAGE_MODE: string;
    static readonly MOCK_CONFIG_JSON5: string;
    static readonly BUILD_DIR_KEY = "ohos.buildDir";
    static readonly HAR_VERSION: string;
    static readonly IS_LOCAL_TEST: string;
    static readonly API_VERSION: string;
    static readonly NO_EXTERNAL_IMPORT_BY_PATH: string;
    static readonly PARAMETER_FILE: string;
}
/**
 * Node环境中的常量
 */
export declare class CommonNodeConst {
    static readonly NODE_EXE: string;
    static readonly NODE: string;
    static readonly NODE_MODULES: string;
}
/**
 * module默认包含的target
 */
export declare class DefaultTargetConst {
    static readonly DEFAULT_TARGET: string;
    static readonly OHOS_TEST_TARGET: string;
}
export declare class BuildProfileSchemaFileConst {
    static readonly HAP_MODULE_BUILD_PROFILE_SCHEMA_PATH: string;
    static readonly HAR_MODULE_BUILD_PROFILE_SCHEMA_PATH: string;
    static readonly PROJECT_BUILD_PROFILE_SCHEMA_PATH: string;
    static readonly ARKUI_X_CONFIG_SCHEMA_PATH: string;
}
export declare class ArkPackConst {
    static readonly COMPILE_TOOL: string;
}
export declare enum PageType {
    PAGE = "page",
    CARD = "card"
}
export declare enum BundleType {
    APP = "app",
    ATOMIC_SERVICE = "atomicService",
    SHARED = "shared"
}
export declare class CustomTypesConst {
    static readonly CUSTOM_TYPES_SUFFIX: string[];
    static readonly CUSTOM_TYPES_INDEX: string[];
}
export declare class UnitTestConst {
    static readonly TEST_BUILD_ROOT = ".test";
    static readonly TEST_ABILITY = "TestAbility";
    static readonly TEST_DEFAULT_MODE = "module";
    static readonly TEST_DEFAULT_REPLACE_PAGE = "../../../.test/testability/pages/Index";
    static readonly TEST_ABILITY_ETS_PATH = "testability/TestAbility.ets";
    static readonly ENTRY_TEST_ABILITY_PATH = "../../.test/testability/TestAbility.ets";
}
export declare class ArktSTaskConst {
    static readonly LEGACY_UNIT_TEST_ARKTS = "LegacyUnitTestArkTS";
    static readonly UNIT_TEST_ARKTS = "UnitTestArkTS";
    static readonly LINT_ARKTS = "LintArkTS";
}
export declare class NativeConst {
    static readonly SHARED_STL_LIBRARY = "libc++_shared.so";
    static readonly PACKAGE_SUMMARY_FILE = "summary.cmake";
    static readonly PACKAGE_NAME_REGEX: RegExp;
    static readonly INCLUDE_DIR = "include";
}
export declare class ValidateRegExp {
    static RELATIVE_PATH_REG_EXP: RegExp;
    static DYNAMIC_IMPORT_FILE_SUFFIX_REG_EXP: RegExp;
    static SO_DEPENDENCY_REG_EXP: RegExp;
    static JS_FILE_SUFFIX_REG_EXP: RegExp;
    static SYSTEM_CAPABILITY_REG_EXP: RegExp;
}
